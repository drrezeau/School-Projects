/**
* the Interface class for Annotations
* Tied to scriptures and topics
**/
public interface Annotation {
	String getDisplayText();
}