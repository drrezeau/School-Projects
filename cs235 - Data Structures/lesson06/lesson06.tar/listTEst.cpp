
#include "list.h"
#include <iostream>
using namespace std;

int main()
{
   List<int> list;
   List<int> list2;

   list.push_back(7);
   list.push_back(2);
   list.push_back(8);
   list.push_back(4);
   list.push_back(7);
   list.push_back(72);
   list.push_back(56);

   for (ListIterator<int> it = list.begin(); it != list.end(); ++it)
   {
      cout << *it << endl;
   }

   list2 = list;

   for (ListIterator<int> it = list2.begin(); it != list2.end(); ++it)
   {
      cout << *it << endl;
   }

   return 0;
}
   
